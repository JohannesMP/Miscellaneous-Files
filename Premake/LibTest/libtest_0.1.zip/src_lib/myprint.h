#pragma once

void myprint(const char *input);
