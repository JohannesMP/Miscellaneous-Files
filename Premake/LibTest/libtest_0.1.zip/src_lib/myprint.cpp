#include <iostream>
#include "myprint.h"

void myprint(const char *input)
{
    std::cout << "myprint: " << input << std::endl;
}
