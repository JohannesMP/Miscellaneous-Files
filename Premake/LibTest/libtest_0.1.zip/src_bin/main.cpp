#include "myprint.h"  // make sure to use -I/Path/Directory

int main(int argc, char **argv)
{
    myprint("HELLO WORLD");
}
