solution "Library Test"
    configurations { "debug", "release" }
    location "make"

    language "C++"
    toolset "clang"

    filter "configurations:Debug"
        defines { "DEBUG" }
        flags { "Symbols" }

    filter "configurations:Release"
        defines { "NDEBUG" }
        optimize "On"



    -- dynamic library containing the 'myprint' function
    project "libtest-lib"
        kind "SharedLib"
        targetname "myprint"
        targetdir "lib"
        files { "src_lib/*.cpp" }

        -- Set the install_name to use @rpath, to allow for relative path for dynamic lib
        filter { "system:macosx", "action:gmake" }
            linkoptions { "-install_name @rpath/libmyprint.dylib" }


    -- simple application that uses the myprint dynamic library
    project "libtest-bin"
        kind "ConsoleApp"
        targetname "main"
        targetdir "bin"
        includedirs {"src_lib"}  -- include the header of the dynamic library
        links { "libtest-lib"}
        files { "src_bin/*.cpp" }

        -- Set the rpath on the executable, to allow for relative path for dynamic lib
        filter { "system:macosx", "action:gmake" }
            linkoptions { "-rpath @executable_path/lib" }

        -- create '/bin/lib' if it does not exist, then copy output from libtest-lib there
        postbuildcommands { "mkdir -p ../bin/lib/", "cp ../lib/*.dylib ../bin/lib/" }

